# Utility functions, if any, can be added here.
def sanitize_string(value):
    return value.strip().lower()
